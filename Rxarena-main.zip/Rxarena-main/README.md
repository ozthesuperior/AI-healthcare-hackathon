
  # RXArena iOS Learning App

  This is a code bundle for RXArena iOS Learning App. The original project is available at https://www.figma.com/design/CtLcJn2uqZ2ugXYVlGx1Gd/RXArena-iOS-Learning-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  