import { NavLink } from 'react-router';
import { CircleHelp, Users, Zap, User } from 'lucide-react';

const tabs = [
  { path: '/', label: 'Focus', icon: CircleHelp, glowColor: 'var(--accent-pink-start)' },
  { path: '/competitive', label: 'Compete', icon: Users, glowColor: 'var(--accent-blue-start)' },
  { path: '/blitz', label: 'Blitz', icon: Zap, glowColor: 'var(--accent-yellow-start)' },
  { path: '/profile', label: 'Profile', icon: User, glowColor: 'var(--accent-green-start)' },
];

export function BottomTabNav() {
  return (
    <div 
      className="absolute flex justify-around items-center z-50"
      style={{
        bottom: '34px',
        left: '20px',
        right: '20px',
        height: '68px',
        background: 'var(--bg-surface-floating)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
        borderRadius: 'var(--radius-pill)',
        padding: '0 8px',
        border: '1px solid rgba(255,255,255,0.05)',
        boxShadow: '0 20px 40px rgba(0,0,0,0.5)'
      }}
    >
      {tabs.map((tab) => (
        <NavLink
          key={tab.path}
          to={tab.path}
          end={tab.path === '/'}
          className="flex flex-col items-center gap-1 w-[60px] cursor-pointer"
          style={{ color: 'var(--text-tertiary)' }}
        >
          {({ isActive }) => (
            <>
              <tab.icon 
                className="w-6 h-6 transition-all" 
                strokeWidth={isActive ? 2.5 : 2}
                style={isActive ? {
                  color: tab.glowColor,
                  filter: `drop-shadow(0 0 8px ${tab.glowColor})`
                } : {}}
              />
              <span 
                className="text-[10px] font-semibold"
                style={{ color: isActive ? 'var(--text-primary)' : 'var(--text-tertiary)' }}
              >
                {tab.label}
              </span>
            </>
          )}
        </NavLink>
      ))}
    </div>
  );
}
