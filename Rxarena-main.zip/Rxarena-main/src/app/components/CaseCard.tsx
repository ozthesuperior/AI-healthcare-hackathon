import { useState } from 'react';
import { motion } from 'motion/react';
import { MedicalCase } from '../data/cases';

interface CaseCardProps {
  case: MedicalCase;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
}

export function CaseCard({ case: medCase, onSwipeLeft, onSwipeRight }: CaseCardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <motion.div
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={(e, { offset, velocity }) => {
        const swipe = offset.x * velocity.x;
        if (swipe > 10000) {
          onSwipeRight?.();
        } else if (swipe < -10000) {
          onSwipeLeft?.();
        }
      }}
      className="w-full cursor-grab active:cursor-grabbing"
      style={{ 
        perspective: 1000,
        flex: 1,
        display: 'flex',
        flexDirection: 'column'
      }}
      onClick={() => setIsFlipped(!isFlipped)}
    >
      <motion.div
        className="relative w-full flex-1"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, type: 'spring', stiffness: 100 }}
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Front of card */}
        <div
          className="absolute inset-0 flex flex-col"
          style={{ 
            backfaceVisibility: 'hidden',
            background: 'linear-gradient(180deg, var(--bg-surface-raised), var(--bg-surface))',
            borderRadius: 'var(--radius-card)',
            padding: '24px',
            border: '1px solid rgba(255,255,255,0.08)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
          }}
        >
          <div className="flex flex-wrap gap-2 mb-4">
            <span 
              className="inline-flex items-center gap-1 text-[13px] font-semibold"
              style={{
                background: '#1A1A1C',
                border: '1px solid rgba(255,255,255,0.05)',
                borderRadius: 'var(--radius-pill)',
                padding: '6px 12px',
                color: 'var(--text-primary)',
                boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.4)'
              }}
            >
              {medCase.gender}, {medCase.age} yrs
            </span>
            <span 
              className="inline-flex items-center gap-1 text-[13px] font-semibold"
              style={{
                background: '#1A1A1C',
                border: '1px solid rgba(255,255,255,0.05)',
                borderRadius: 'var(--radius-pill)',
                padding: '6px 12px',
                color: 'var(--text-primary)',
                boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.4)'
              }}
            >
              {medCase.id}
            </span>
          </div>

          <p 
            className="text-[18px] leading-[1.5] mb-auto"
            style={{
              color: 'var(--text-secondary)',
              fontFamily: 'var(--font-family)'
            }}
          >
            {medCase.summary}
          </p>

          <div className="mt-6">
            <div 
              className="text-[13px] font-semibold uppercase mb-2"
              style={{
                color: 'var(--text-secondary)',
                letterSpacing: '0.5px'
              }}
            >
              Associated ICD Codes
            </div>
            <div className="flex flex-wrap gap-2">
              {medCase.icdCodes.map((code) => (
                <span
                  key={code}
                  className="text-[13px] font-semibold"
                  style={{
                    background: '#1A1A1C',
                    border: '1px solid rgba(255,255,255,0.05)',
                    borderRadius: 'var(--radius-pill)',
                    padding: '6px 12px',
                    color: 'var(--accent-blue-start)',
                    boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.4)'
                  }}
                >
                  {code}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Back of card */}
        <div
          className="absolute inset-0 flex flex-col items-center justify-center text-center"
          style={{ 
            backfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
            background: 'linear-gradient(180deg, var(--bg-surface-raised), var(--bg-surface))',
            borderRadius: 'var(--radius-card)',
            padding: '24px',
            border: '1px solid rgba(255,255,255,0.08)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
          }}
        >
          <h1 
            className="text-[42px] font-bold mb-2"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--accent-blue-start)',
              textShadow: '0 0 12px rgba(0,229,255,0.5)',
              letterSpacing: '-0.5px'
            }}
          >
            {medCase.diagnosisShort}
          </h1>
          
          <h2 
            className="text-[18px] font-semibold mb-5"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--text-secondary)'
            }}
          >
            {medCase.admissionDiagnosis}
          </h2>
          
          <span 
            className="text-[13px] font-semibold mb-8"
            style={{
              background: '#1A1A1C',
              border: '1px solid rgba(255,255,255,0.05)',
              borderRadius: 'var(--radius-pill)',
              padding: '6px 12px',
              color: 'var(--accent-blue-start)',
              boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.4)'
            }}
          >
            ICD: {medCase.icdCodes[0]}
          </span>
          
          <p 
            className="text-[16px] leading-[1.5] text-left"
            style={{
              background: 'var(--bg-base)',
              padding: '16px',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid rgba(255,255,255,0.05)',
              color: 'var(--text-secondary)'
            }}
          >
            {medCase.diagnosisLong}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}
