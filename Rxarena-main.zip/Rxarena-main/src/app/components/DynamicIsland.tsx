export function DynamicIsland() {
  return (
    <div 
      className="absolute z-[100]" 
      style={{
        top: '11px',
        left: '50%',
        transform: 'translateX(-50%)',
        width: '120px',
        height: '32px',
        background: '#000',
        borderRadius: '20px'
      }}
    />
  );
}
