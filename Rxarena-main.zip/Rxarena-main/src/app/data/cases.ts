export interface MedicalCase {
  id: string;
  admissionDiagnosis: string;
  gender: string;
  age: number;
  summary: string;
  diagnosisShort: string;
  diagnosisLong: string;
  icdCodes: string[];
}

export const medicalCases: MedicalCase[] = [
  {
    id: "CASE-2847",
    admissionDiagnosis: "Acute Chest Pain",
    gender: "Male",
    age: 58,
    summary: "58M presenting with sudden onset crushing substernal chest pain radiating to left arm. Diaphoresis and nausea present. ECG shows ST elevation in leads II, III, aVF.",
    diagnosisShort: "Inferior STEMI",
    diagnosisLong: "ST-Elevation Myocardial Infarction (Inferior Wall) - Acute coronary syndrome requiring immediate reperfusion therapy",
    icdCodes: ["I21.19", "I25.10"]
  },
  {
    id: "CASE-3921",
    admissionDiagnosis: "Severe Headache",
    gender: "Female",
    age: 42,
    summary: "42F with worst headache of life, sudden onset, associated with neck stiffness and photophobia. No focal neurological deficits. BP 165/95.",
    diagnosisShort: "Subarachnoid Hemorrhage",
    diagnosisLong: "Non-traumatic subarachnoid hemorrhage - likely aneurysmal bleed requiring urgent CT angiography and neurosurgical consultation",
    icdCodes: ["I60.9", "G44.53"]
  },
  {
    id: "CASE-1563",
    admissionDiagnosis: "Shortness of Breath",
    gender: "Female",
    age: 67,
    summary: "67F with progressive dyspnea over 3 days, orthopnea, and bilateral lower extremity edema. JVD present. Crackles at lung bases bilaterally. Known history of HTN.",
    diagnosisShort: "Acute Decompensated HF",
    diagnosisLong: "Acute Decompensated Heart Failure - Volume overload requiring diuresis and optimization of cardiac medications",
    icdCodes: ["I50.9", "I11.0"]
  },
  {
    id: "CASE-4782",
    admissionDiagnosis: "Altered Mental Status",
    gender: "Male",
    age: 72,
    summary: "72M brought in by family with confusion and agitation over 24 hours. Fever 39.2°C, tachycardic. Positive Kernig and Brudzinski signs. Recent URI symptoms.",
    diagnosisShort: "Bacterial Meningitis",
    diagnosisLong: "Acute bacterial meningitis - Requires immediate empiric antibiotics and lumbar puncture for CSF analysis",
    icdCodes: ["G00.9", "G03.9"]
  },
  {
    id: "CASE-6154",
    admissionDiagnosis: "Abdominal Pain",
    gender: "Female",
    age: 28,
    summary: "28F with RLQ pain, nausea, and vomiting for 12 hours. Pain initially periumbilical, now localized. Fever 38.1°C. Positive Rovsing sign, rebound tenderness.",
    diagnosisShort: "Acute Appendicitis",
    diagnosisLong: "Acute appendicitis - Surgical emergency requiring appendectomy to prevent perforation and peritonitis",
    icdCodes: ["K35.80", "K37"]
  },
  {
    id: "CASE-2319",
    admissionDiagnosis: "Syncope",
    gender: "Male",
    age: 81,
    summary: "81M with sudden loss of consciousness preceded by palpitations. Witnessed fall. ECG shows irregular rhythm, absent P waves, variable R-R intervals. HR 140-160.",
    diagnosisShort: "Atrial Fibrillation with RVR",
    diagnosisLong: "Atrial fibrillation with rapid ventricular response - Requires rate control and anticoagulation consideration",
    icdCodes: ["I48.91", "R55"]
  },
  {
    id: "CASE-5847",
    admissionDiagnosis: "Fever and Cough",
    gender: "Male",
    age: 45,
    summary: "45M with productive cough, rust-colored sputum, and high fever for 3 days. Right-sided pleuritic chest pain. Exam shows dullness to percussion and bronchial breath sounds RLL.",
    diagnosisShort: "Lobar Pneumonia",
    diagnosisLong: "Community-acquired pneumonia (lobar) - Likely pneumococcal, requires antibiotic therapy and supportive care",
    icdCodes: ["J18.1", "J15.9"]
  },
  {
    id: "CASE-7293",
    admissionDiagnosis: "Severe Epigastric Pain",
    gender: "Female",
    age: 52,
    summary: "52F with sudden severe epigastric pain radiating to back after large meal. Nausea, vomiting. Tender epigastrium. Lipase 1200 U/L. Known cholelithiasis.",
    diagnosisShort: "Acute Pancreatitis",
    diagnosisLong: "Acute pancreatitis (gallstone-induced) - Requires NPO, IV fluids, pain control, and monitoring for complications",
    icdCodes: ["K85.9", "K80.20"]
  },
  {
    id: "CASE-4126",
    admissionDiagnosis: "Weakness and Tremor",
    gender: "Male",
    age: 63,
    summary: "63M with progressive resting tremor in right hand, bradykinesia, and masked facies over 18 months. Shuffling gait noted. Cogwheel rigidity on exam.",
    diagnosisShort: "Parkinson Disease",
    diagnosisLong: "Parkinson's disease - Neurodegenerative disorder requiring dopaminergic therapy and multidisciplinary management",
    icdCodes: ["G20", "G21.9"]
  },
  {
    id: "CASE-8561",
    admissionDiagnosis: "Diabetic Complications",
    gender: "Female",
    age: 34,
    summary: "34F with type 1 diabetes, presenting with nausea, vomiting, and abdominal pain. Fruity breath odor. Glucose 520 mg/dL, pH 7.15, positive ketones.",
    diagnosisShort: "Diabetic Ketoacidosis",
    diagnosisLong: "Diabetic ketoacidosis - Life-threatening complication requiring IV insulin, fluid resuscitation, and electrolyte monitoring",
    icdCodes: ["E10.10", "E87.2"]
  },
  {
    id: "CASE-9374",
    admissionDiagnosis: "Joint Pain",
    gender: "Male",
    age: 48,
    summary: "48M with severe sudden onset pain in right first MTP joint, awoke from sleep. Joint red, swollen, exquisitely tender. History of beer consumption. Uric acid 9.8 mg/dL.",
    diagnosisShort: "Acute Gout",
    diagnosisLong: "Acute gouty arthritis - Crystal-induced inflammatory arthritis requiring NSAIDs/colchicine and uric acid lowering therapy",
    icdCodes: ["M10.071", "M79.9"]
  },
  {
    id: "CASE-2658",
    admissionDiagnosis: "Seizure Activity",
    gender: "Female",
    age: 19,
    summary: "19F with witnessed generalized tonic-clonic seizure lasting 3 minutes. Postictal confusion. No prior seizure history. Recent sleep deprivation for exams.",
    diagnosisShort: "New-Onset Seizure",
    diagnosisLong: "First unprovoked seizure - Requires neuroimaging, EEG, and consideration of anti-epileptic therapy based on recurrence risk",
    icdCodes: ["R56.9", "G40.909"]
  }
];

export interface QuizQuestion {
  id: string;
  caseSnippet: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: "Q1",
    caseSnippet: "58M with crushing chest pain radiating to left arm, ST elevation in II, III, aVF",
    options: ["Anterior STEMI", "Inferior STEMI", "Pulmonary Embolism", "Aortic Dissection"],
    correctAnswer: 1,
    explanation: "ST elevation in inferior leads (II, III, aVF) indicates inferior wall MI"
  },
  {
    id: "Q2",
    caseSnippet: "42F with sudden worst headache of life, neck stiffness, photophobia",
    options: ["Migraine", "Tension Headache", "Subarachnoid Hemorrhage", "Meningitis"],
    correctAnswer: 2,
    explanation: "Sudden severe headache with meningeal signs suggests SAH"
  },
  {
    id: "Q3",
    caseSnippet: "67F with dyspnea, orthopnea, bilateral leg edema, JVD, lung crackles",
    options: ["COPD Exacerbation", "Pneumonia", "Acute Heart Failure", "Pulmonary Fibrosis"],
    correctAnswer: 2,
    explanation: "Volume overload signs (JVD, edema, crackles) indicate heart failure"
  },
  {
    id: "Q4",
    caseSnippet: "28F with RLQ pain, fever, positive Rovsing sign, rebound tenderness",
    options: ["Ectopic Pregnancy", "Ovarian Torsion", "Acute Appendicitis", "UTI"],
    correctAnswer: 2,
    explanation: "RLQ pain with peritoneal signs strongly suggests appendicitis"
  },
  {
    id: "Q5",
    caseSnippet: "81M with syncope, irregular rhythm, absent P waves, HR 140-160",
    options: ["Sinus Tachycardia", "Atrial Fibrillation", "VT", "Complete Heart Block"],
    correctAnswer: 1,
    explanation: "Irregularly irregular rhythm without P waves is pathognomonic for A-fib"
  },
  {
    id: "Q6",
    caseSnippet: "45M with productive cough, rust-colored sputum, fever, RLL dullness",
    options: ["Bronchitis", "Lobar Pneumonia", "Lung Cancer", "Pulmonary Edema"],
    correctAnswer: 1,
    explanation: "Consolidation signs with rust sputum indicate lobar pneumonia"
  },
  {
    id: "Q7",
    caseSnippet: "52F with severe epigastric pain to back, lipase 1200, history of gallstones",
    options: ["PUD", "Acute Pancreatitis", "Cholecystitis", "MI"],
    correctAnswer: 1,
    explanation: "Elevated lipase and gallstone history indicate gallstone pancreatitis"
  },
  {
    id: "Q8",
    caseSnippet: "63M with resting tremor, bradykinesia, cogwheel rigidity, shuffling gait",
    options: ["Essential Tremor", "Parkinson Disease", "Cerebellar Stroke", "MS"],
    correctAnswer: 1,
    explanation: "Classic triad of tremor, rigidity, bradykinesia indicates Parkinson's"
  },
  {
    id: "Q9",
    caseSnippet: "34F T1DM with glucose 520, pH 7.15, positive ketones, fruity breath",
    options: ["HHS", "DKA", "Hypoglycemia", "Lactic Acidosis"],
    correctAnswer: 1,
    explanation: "Hyperglycemia with acidosis and ketones defines DKA"
  },
  {
    id: "Q10",
    caseSnippet: "48M with sudden severe right 1st MTP pain, red swollen joint, uric acid 9.8",
    options: ["Septic Arthritis", "Acute Gout", "RA", "Pseudogout"],
    correctAnswer: 1,
    explanation: "1st MTP involvement with hyperuricemia indicates gout"
  },
  {
    id: "Q11",
    caseSnippet: "72M with confusion, fever 39.2°C, positive Kernig and Brudzinski signs",
    options: ["Encephalitis", "Bacterial Meningitis", "Sepsis", "Brain Abscess"],
    correctAnswer: 1,
    explanation: "Meningeal signs with fever indicate bacterial meningitis"
  },
  {
    id: "Q12",
    caseSnippet: "19F with witnessed 3-minute tonic-clonic seizure, postictal confusion",
    options: ["Syncope", "Pseudoseizure", "New-Onset Seizure", "Stroke"],
    correctAnswer: 2,
    explanation: "First generalized tonic-clonic seizure requires workup"
  }
];
