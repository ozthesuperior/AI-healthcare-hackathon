import { createBrowserRouter } from 'react-router';
import { Root } from './screens/Root';
import { Focus } from './screens/Focus';
import { Competitive } from './screens/Competitive';
import { Blitz } from './screens/Blitz';
import { Profile } from './screens/Profile';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: Focus },
      { path: 'competitive', Component: Competitive },
      { path: 'blitz', Component: Blitz },
      { path: 'profile', Component: Profile },
    ],
  },
]);
