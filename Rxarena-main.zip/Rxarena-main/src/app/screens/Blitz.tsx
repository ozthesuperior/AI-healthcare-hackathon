import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { quizQuestions } from '../data/cases';

type Difficulty = 'easy' | 'medium' | 'hard';
type GameState = 'setup' | 'playing' | 'results';

export function Blitz() {
  const [gameState, setGameState] = useState<GameState>('setup');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [totalCorrect, setTotalCorrect] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);

  const timePerQuestion = { easy: 15, medium: 10, hard: 7 }[difficulty];
  const totalQuestions = quizQuestions.length;
  const question = quizQuestions[currentQuestion];

  useEffect(() => {
    if (gameState === 'playing' && timeLeft > 0 && selectedAnswer === null) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && selectedAnswer === null) {
      handleAnswer(null);
    }
  }, [gameState, timeLeft, selectedAnswer]);

  const handleStart = () => {
    setGameState('playing');
    setCurrentQuestion(0);
    setTimeLeft(timePerQuestion);
    setStreak(0);
    setTotalCorrect(0);
    setSelectedAnswer(null);
  };

  const handleAnswer = (answerIndex: number | null) => {
    setSelectedAnswer(answerIndex);
    const isCorrect = answerIndex === question.correctAnswer;

    if (isCorrect) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      setTotalCorrect(totalCorrect + 1);
      if (newStreak > bestStreak) {
        setBestStreak(newStreak);
      }
    } else {
      setStreak(0);
    }

    setTimeout(() => {
      if (currentQuestion < totalQuestions - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setTimeLeft(timePerQuestion);
        setSelectedAnswer(null);
      } else {
        setGameState('results');
      }
    }, 800);
  };

  const tileColors = [
    'linear-gradient(135deg, var(--accent-blue-start), var(--accent-blue-end))',
    'linear-gradient(135deg, var(--accent-pink-start), var(--accent-pink-end))',
    'linear-gradient(135deg, var(--accent-green-start), var(--accent-green-end))',
    'linear-gradient(135deg, var(--accent-yellow-start), var(--accent-yellow-end))'
  ];

  if (gameState === 'setup') {
    return (
      <div 
        className="flex-1 flex flex-col relative z-10 overflow-y-auto"
        style={{ padding: '54px 20px 120px 20px' }}
      >
        <h1 
          className="text-[28px] font-bold mb-6"
          style={{
            marginTop: '20px',
            fontFamily: 'var(--font-rounded)',
            letterSpacing: '-0.5px',
            color: 'var(--text-primary)'
          }}
        >
          Blitz Mode
        </h1>

        {/* Difficulty selector */}
        <div className="mb-6" style={{
          background: 'var(--bg-surface-raised)',
          borderRadius: 'var(--radius-pill)',
          padding: '4px',
          display: 'flex',
          border: '1px solid rgba(255,255,255,0.05)'
        }}>
          {(['easy', 'medium', 'hard'] as Difficulty[]).map((level) => (
            <div
              key={level}
              onClick={() => setDifficulty(level)}
              className="flex-1 text-center cursor-pointer text-[13px] font-semibold"
              style={{
                padding: '8px',
                color: difficulty === level ? 'var(--text-primary)' : 'var(--text-secondary)',
                background: difficulty === level ? 'var(--bg-surface)' : 'transparent',
                borderRadius: 'var(--radius-pill)',
                boxShadow: difficulty === level ? '0 2px 8px rgba(0,0,0,0.5)' : 'none',
                transition: 'all 0.2s'
              }}
            >
              {level.charAt(0).toUpperCase() + level.slice(1)}
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between mb-4">
          <div 
            className="text-[13px] font-semibold"
            style={{
              background: '#1A1A1C',
              border: '1px solid rgba(255, 214, 10, 0.3)',
              borderRadius: 'var(--radius-pill)',
              padding: '6px 12px',
              color: 'var(--accent-yellow-start)'
            }}
          >
            🔥 {bestStreak} Best Streak
          </div>
        </div>

        <div 
          className="flex flex-col gap-6 flex-1 justify-center items-center text-center mb-6"
          style={{
            background: 'linear-gradient(180deg, var(--bg-surface-raised), var(--bg-surface))',
            borderRadius: 'var(--radius-card)',
            padding: '24px',
            border: '1px solid rgba(255,255,255,0.08)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
            minHeight: '180px'
          }}
        >
          <h2 className="text-[28px] leading-[1.3]" style={{ fontFamily: 'var(--font-rounded)', color: 'var(--text-primary)' }}>
            Ready for speed?
          </h2>
          <p className="text-[16px]" style={{ color: 'var(--text-secondary)' }}>
            Answer {totalQuestions} questions as fast as you can
          </p>
        </div>

        <button
          onClick={handleStart}
          className="w-full text-[17px] font-bold relative overflow-hidden"
          style={{
            border: 'none',
            borderRadius: 'var(--radius-pill)',
            padding: '16px 24px',
            background: 'linear-gradient(135deg, var(--accent-yellow-start), var(--accent-yellow-end))',
            boxShadow: 'inset 0 2px 0 rgba(255,255,255,0.5), 0 4px 12px rgba(0,0,0,0.2)',
            color: '#000',
            cursor: 'pointer'
          }}
        >
          <span 
            className="absolute inset-0 pointer-events-none"
            style={{
              top: 0,
              left: 0,
              right: 0,
              height: '40%',
              background: 'linear-gradient(to bottom, rgba(255,255,255,0.15), transparent)'
            }}
          />
          Start Blitz
        </button>
      </div>
    );
  }

  if (gameState === 'results') {
    return (
      <div 
        className="flex-1 flex flex-col relative z-10 items-center justify-center"
        style={{ padding: '54px 20px 120px 20px' }}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-full text-center"
        >
          <h1 
            className="text-[48px] font-bold mb-2"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--accent-yellow-start)',
              textShadow: '0 0 12px rgba(255,214,10,0.5)'
            }}
          >
            {bestStreak}
          </h1>
          <p className="text-[18px] mb-8" style={{ color: 'var(--text-secondary)' }}>
            Best Streak
          </p>

          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="text-center" style={{ padding: '16px', background: 'var(--bg-surface)', borderRadius: 'var(--radius-sm)' }}>
              <div className="text-[24px] font-bold" style={{ fontFamily: 'var(--font-rounded)', color: 'var(--accent-green-start)' }}>
                {totalCorrect}/{totalQuestions}
              </div>
              <div className="text-[11px] font-semibold uppercase" style={{ color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
                Correct
              </div>
            </div>
            <div className="text-center" style={{ padding: '16px', background: 'var(--bg-surface)', borderRadius: 'var(--radius-sm)' }}>
              <div className="text-[24px] font-bold" style={{ fontFamily: 'var(--font-rounded)', color: 'var(--accent-blue-start)' }}>
                {Math.round((totalCorrect / totalQuestions) * 100)}%
              </div>
              <div className="text-[11px] font-semibold uppercase" style={{ color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
                Accuracy
              </div>
            </div>
          </div>

          <button
            onClick={handleStart}
            className="w-full text-[17px] font-bold relative overflow-hidden"
            style={{
              border: 'none',
              borderRadius: 'var(--radius-pill)',
              padding: '16px 24px',
              background: 'linear-gradient(135deg, var(--accent-yellow-start), var(--accent-yellow-end))',
              boxShadow: 'inset 0 2px 0 rgba(255,255,255,0.5), 0 4px 12px rgba(0,0,0,0.2)',
              color: '#000',
              cursor: 'pointer'
            }}
          >
            <span 
              className="absolute inset-0 pointer-events-none"
              style={{
                top: 0,
                left: 0,
                right: 0,
                height: '40%',
                background: 'linear-gradient(to bottom, rgba(255,255,255,0.15), transparent)'
              }}
            />
            Play Again
          </button>
        </motion.div>
      </div>
    );
  }

  // Playing state
  return (
    <div 
      className="flex-1 flex flex-col relative z-10"
      style={{ padding: '54px 20px 120px 20px' }}
    >
      <div className="flex items-center justify-between mb-4" style={{ marginTop: '16px' }}>
        <div 
          className="text-[13px] font-semibold"
          style={{
            background: '#1A1A1C',
            border: '1px solid rgba(255, 214, 10, 0.3)',
            borderRadius: 'var(--radius-pill)',
            padding: '6px 12px',
            color: 'var(--accent-yellow-start)'
          }}
        >
          🔥 {streak} Streak
        </div>
      </div>

      {/* Progress bar */}
      <div 
        className="mb-8"
        style={{
          height: '4px',
          background: '#333',
          borderRadius: '2px',
          overflow: 'hidden'
        }}
      >
        <div 
          style={{
            height: '100%',
            width: `${(timeLeft / timePerQuestion) * 100}%`,
            background: 'linear-gradient(90deg, var(--accent-pink-start), var(--accent-yellow-start))',
            borderRadius: '2px',
            transition: 'width 1s linear'
          }}
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="flex-1 flex flex-col"
        >
          {/* Question card */}
          <div 
            className="flex flex-col items-center justify-center text-center mb-8 flex-1"
            style={{
              background: 'linear-gradient(180deg, var(--bg-surface-raised), var(--bg-surface))',
              borderRadius: 'var(--radius-card)',
              padding: '24px',
              border: '1px solid rgba(255,255,255,0.08)',
              boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
              minHeight: '180px'
            }}
          >
            <h2 className="text-[28px] leading-[1.3]" style={{ fontFamily: 'var(--font-rounded)', color: 'var(--text-primary)' }}>
              {question.caseSnippet}
            </h2>
          </div>

          {/* Answer tiles */}
          <div className="grid grid-cols-2 gap-3">
            {question.options.map((option, index) => {
              const isCorrect = index === question.correctAnswer;
              const isSelected = index === selectedAnswer;
              let tileStyle = {
                background: tileColors[index],
                boxShadow: index === 3 ? 'inset 0 2px 0 rgba(255,255,255,0.5), 0 4px 12px rgba(0,0,0,0.2)' : 'inset 0 2px 0 rgba(255,255,255,0.2), 0 4px 12px rgba(0,0,0,0.2)',
                color: index === 3 ? '#000' : '#FFF'
              };

              if (selectedAnswer !== null) {
                if (isCorrect) {
                  tileStyle.background = 'linear-gradient(135deg, var(--accent-green-start), var(--accent-green-end))';
                  tileStyle.color = '#FFF';
                } else {
                  tileStyle.background = 'var(--bg-surface-raised)';
                  tileStyle.boxShadow = 'none';
                  tileStyle.color = 'var(--text-tertiary)';
                }
              }

              return (
                <button
                  key={index}
                  onClick={() => selectedAnswer === null && handleAnswer(index)}
                  disabled={selectedAnswer !== null}
                  className="relative overflow-hidden text-[14px] font-bold text-center flex items-center justify-center"
                  style={{
                    ...tileStyle,
                    border: 'none',
                    borderRadius: '20px',
                    padding: '12px',
                    minHeight: '80px',
                    cursor: selectedAnswer === null ? 'pointer' : 'default'
                  }}
                >
                  <span 
                    className="absolute inset-0 pointer-events-none"
                    style={{
                      top: 0,
                      left: 0,
                      right: 0,
                      height: '40%',
                      background: selectedAnswer !== null && !isCorrect ? 'none' : 'linear-gradient(to bottom, rgba(255,255,255,0.15), transparent)'
                    }}
                  />
                  {option}
                </button>
              );
            })}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
