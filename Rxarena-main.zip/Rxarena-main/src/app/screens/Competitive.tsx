import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { quizQuestions } from '../data/cases';
import { Star } from 'lucide-react';

type GameState = 'lobby' | 'playing' | 'results';

export function Competitive() {
  const [gameState, setGameState] = useState<GameState>('lobby');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(20);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [playerName, setPlayerName] = useState('');

  const question = quizQuestions[currentQuestion];

  useEffect(() => {
    if (gameState === 'playing' && !showResult && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showResult) {
      handleAnswer(null);
    }
  }, [gameState, timeLeft, showResult]);

  const handleStart = () => {
    if (playerName.trim()) {
      setGameState('playing');
      setCurrentQuestion(0);
      setScore(0);
      setTimeLeft(20);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  const handleAnswer = (answerIndex: number | null) => {
    setSelectedAnswer(answerIndex);
    setShowResult(true);
    
    if (answerIndex === question.correctAnswer) {
      const timeBonus = Math.floor(timeLeft / 2);
      setScore(score + 100 + timeBonus);
    }

    setTimeout(() => {
      if (currentQuestion < quizQuestions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setTimeLeft(20);
        setSelectedAnswer(null);
        setShowResult(false);
      } else {
        setGameState('results');
      }
    }, 2000);
  };

  const tileColors = [
    'linear-gradient(135deg, var(--accent-red-start), var(--accent-red-end))',
    'linear-gradient(135deg, var(--accent-blue-start), var(--accent-blue-end))',
    'linear-gradient(135deg, var(--accent-yellow-start), var(--accent-yellow-end))',
    'linear-gradient(135deg, var(--accent-green-start), var(--accent-green-end))'
  ];

  if (gameState === 'lobby') {
    return (
      <div 
        className="flex-1 flex flex-col relative z-10 overflow-y-auto"
        style={{ padding: '54px 20px 120px 20px' }}
      >
        <h1 
          className="text-[28px] font-bold mb-6"
          style={{
            marginTop: '20px',
            fontFamily: 'var(--font-rounded)',
            letterSpacing: '-0.5px',
            color: 'var(--text-primary)'
          }}
        >
          Competitive
        </h1>

        <div 
          className="flex flex-col gap-6"
          style={{
            background: 'var(--bg-surface)',
            borderRadius: 'var(--radius-card)',
            padding: '24px',
            border: '1px solid rgba(255,255,255,0.03)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
          }}
        >
          <input
            type="text"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            className="w-full px-4 py-3 text-[17px]"
            style={{
              background: 'var(--bg-base)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: 'var(--radius-sm)',
              color: 'var(--text-primary)',
              fontFamily: 'var(--font-family)'
            }}
          />

          <div className="grid grid-cols-3 gap-3">
            <div className="text-center" style={{ padding: '16px', background: 'var(--bg-base)', borderRadius: 'var(--radius-sm)' }}>
              <div className="text-[24px] font-bold" style={{ fontFamily: 'var(--font-rounded)', color: 'var(--accent-blue-start)' }}>
                {quizQuestions.length}
              </div>
              <div className="text-[11px] font-semibold uppercase" style={{ color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
                Questions
              </div>
            </div>
            <div className="text-center" style={{ padding: '16px', background: 'var(--bg-base)', borderRadius: 'var(--radius-sm)' }}>
              <div className="text-[24px] font-bold" style={{ fontFamily: 'var(--font-rounded)', color: 'var(--accent-blue-start)' }}>
                20s
              </div>
              <div className="text-[11px] font-semibold uppercase" style={{ color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
                Per Q
              </div>
            </div>
            <div className="text-center" style={{ padding: '16px', background: 'var(--bg-base)', borderRadius: 'var(--radius-sm)' }}>
              <div className="text-[24px] font-bold" style={{ fontFamily: 'var(--font-rounded)', color: 'var(--accent-blue-start)' }}>
                100+
              </div>
              <div className="text-[11px] font-semibold uppercase" style={{ color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
                Points
              </div>
            </div>
          </div>

          <button
            onClick={handleStart}
            disabled={!playerName.trim()}
            className="w-full text-[17px] font-bold relative overflow-hidden disabled:opacity-30"
            style={{
              border: 'none',
              borderRadius: 'var(--radius-pill)',
              padding: '16px 24px',
              background: 'linear-gradient(135deg, var(--accent-blue-start), var(--accent-blue-end))',
              boxShadow: 'inset 0 2px 0 rgba(255,255,255,0.3), 0 8px 20px rgba(0,122,255,0.3)',
              color: '#FFF',
              cursor: playerName.trim() ? 'pointer' : 'not-allowed'
            }}
          >
            <span 
              className="absolute inset-0 pointer-events-none"
              style={{
                top: 0,
                left: 0,
                right: 0,
                height: '50%',
                background: 'linear-gradient(to bottom, rgba(255,255,255,0.15), transparent)',
                borderRadius: 'var(--radius-pill) var(--radius-pill) 0 0'
              }}
            />
            Start Game
          </button>
        </div>
      </div>
    );
  }

  if (gameState === 'results') {
    return (
      <div 
        className="flex-1 flex flex-col relative z-10 items-center justify-center text-center"
        style={{ padding: '54px 20px 120px 20px' }}
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-full"
        >
          <h1 
            className="text-[48px] font-bold mb-2"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--accent-green-start)',
              textShadow: '0 0 12px rgba(52,199,89,0.5)'
            }}
          >
            Correct!
          </h1>
          
          <div 
            className="text-[13px] font-semibold mb-8"
            style={{
              background: '#1A1A1C',
              border: '1px solid rgba(255,255,255,0.05)',
              borderRadius: 'var(--radius-pill)',
              padding: '6px 12px',
              color: 'var(--accent-blue-start)',
              boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.4)',
              display: 'inline-block'
            }}
          >
            Final Score: {score}
          </div>

          <button
            onClick={() => setGameState('lobby')}
            className="w-full text-[17px] font-bold relative overflow-hidden"
            style={{
              border: 'none',
              borderRadius: 'var(--radius-pill)',
              padding: '16px 24px',
              background: 'linear-gradient(135deg, var(--accent-blue-start), var(--accent-blue-end))',
              boxShadow: 'inset 0 2px 0 rgba(255,255,255,0.3), 0 8px 20px rgba(0,122,255,0.3)',
              color: '#FFF',
              cursor: 'pointer'
            }}
          >
            <span 
              className="absolute inset-0 pointer-events-none"
              style={{
                top: 0,
                left: 0,
                right: 0,
                height: '50%',
                background: 'linear-gradient(to bottom, rgba(255,255,255,0.15), transparent)',
                borderRadius: 'var(--radius-pill) var(--radius-pill) 0 0'
              }}
            />
            Play Again
          </button>
        </motion.div>
      </div>
    );
  }

  // Playing state
  const progress = (timeLeft / 20) * 100;

  return (
    <div 
      className="flex-1 flex flex-col relative z-10"
      style={{ padding: '54px 20px 120px 20px' }}
    >
      {/* Header with timer */}
      <div 
        className="flex items-center justify-between mb-6"
        style={{
          marginTop: '16px',
          background: 'rgba(28,28,30,0.8)',
          padding: '12px',
          borderRadius: 'var(--radius-pill)',
          border: '1px solid rgba(255,255,255,0.05)'
        }}
      >
        <div 
          className="text-[13px] font-semibold"
          style={{
            background: 'var(--bg-base)',
            borderRadius: 'var(--radius-pill)',
            padding: '6px 12px',
            color: 'var(--text-primary)'
          }}
        >
          Q{currentQuestion + 1}/{quizQuestions.length}
        </div>
        
        <div 
          className="flex items-center justify-center"
          style={{
            width: '44px',
            height: '44px',
            borderRadius: '50%',
            background: `conic-gradient(var(--accent-pink-start) ${progress}%, #333 0)`
          }}
        >
          <div 
            className="flex items-center justify-center text-[14px] font-bold"
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              background: 'var(--bg-surface-raised)',
              fontFamily: 'var(--font-rounded)',
              color: 'var(--text-primary)'
            }}
          >
            {timeLeft}
          </div>
        </div>

        <div 
          className="flex items-center gap-1 text-[13px] font-semibold"
          style={{
            background: 'var(--bg-base)',
            borderRadius: 'var(--radius-pill)',
            padding: '6px 12px',
            color: 'var(--accent-yellow-start)'
          }}
        >
          <Star className="w-[14px] h-[14px]" fill="currentColor" />
          {score} pts
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="flex-1 flex flex-col"
        >
          {/* Question card */}
          <div 
            className="text-center mb-6"
            style={{
              background: 'var(--bg-surface)',
              borderRadius: 'var(--radius-card)',
              padding: '20px',
              border: '1px solid rgba(255,255,255,0.03)',
              boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
            }}
          >
            <p className="text-[17px] leading-[1.5]" style={{ color: 'var(--text-primary)' }}>
              {question.caseSnippet}
            </p>
          </div>

          {/* Answer tiles */}
          <div className="grid grid-cols-2 gap-3 mt-auto">
            {question.options.map((option, index) => {
              const isCorrect = index === question.correctAnswer;
              const isSelected = index === selectedAnswer;
              let tileStyle = {
                background: tileColors[index],
                boxShadow: 'inset 0 2px 0 rgba(255,255,255,0.2), 0 4px 12px rgba(0,0,0,0.2)',
                color: index === 2 ? '#000' : '#FFF'
              };

              if (showResult) {
                if (isCorrect) {
                  tileStyle.background = 'linear-gradient(135deg, var(--accent-green-start), var(--accent-green-end))';
                  tileStyle.boxShadow = 'inset 0 2px 0 rgba(255,255,255,0.3), 0 8px 20px rgba(52,199,89,0.4)';
                  tileStyle.color = '#FFF';
                } else if (!isCorrect) {
                  tileStyle.background = 'var(--bg-surface-raised)';
                  tileStyle.boxShadow = 'none';
                  tileStyle.color = 'var(--text-tertiary)';
                }
              }

              return (
                <button
                  key={index}
                  onClick={() => !showResult && handleAnswer(index)}
                  disabled={showResult}
                  className="relative overflow-hidden text-[16px] font-bold text-center flex items-center justify-center"
                  style={{
                    ...tileStyle,
                    border: 'none',
                    borderRadius: '20px',
                    padding: '20px 16px',
                    minHeight: '100px',
                    cursor: showResult ? 'default' : 'pointer'
                  }}
                >
                  <span 
                    className="absolute inset-0 pointer-events-none"
                    style={{
                      top: 0,
                      left: 0,
                      right: 0,
                      height: '40%',
                      background: showResult && !isCorrect ? 'none' : 'linear-gradient(to bottom, rgba(255,255,255,0.15), transparent)'
                    }}
                  />
                  {option}
                </button>
              );
            })}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
