import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CaseCard } from '../components/CaseCard';
import { medicalCases } from '../data/cases';
import { RotateCcw } from 'lucide-react';

export function Focus() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [savedCases, setSavedCases] = useState<string[]>([]);

  const currentCase = medicalCases[currentIndex];

  const handleSkip = () => {
    if (currentIndex < medicalCases.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setCurrentIndex(0);
    }
  };

  const handleKeep = () => {
    if (currentCase && !savedCases.includes(currentCase.id)) {
      setSavedCases([...savedCases, currentCase.id]);
    }
    handleSkip();
  };

  return (
    <div 
      className="flex-1 flex flex-col relative z-10 overflow-y-hidden"
      style={{
        padding: '54px 20px 120px 20px'
      }}
    >
      <div className="flex items-center justify-between mb-6" style={{ marginTop: '20px' }}>
        <h1 
          className="text-[28px] font-bold"
          style={{
            fontFamily: 'var(--font-rounded)',
            letterSpacing: '-0.5px',
            color: 'var(--text-primary)'
          }}
        >
          Focus Mode
        </h1>
        <div 
          className="text-[13px] font-semibold"
          style={{
            background: '#1A1A1C',
            border: '1px solid rgba(255,255,255,0.05)',
            borderRadius: 'var(--radius-pill)',
            padding: '6px 12px',
            color: 'var(--text-primary)',
            boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.4)'
          }}
        >
          Case {currentIndex + 1}/{medicalCases.length}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentCase.id}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3 }}
          className="flex-1 flex flex-col mb-6"
        >
          <CaseCard
            case={currentCase}
            onSwipeLeft={handleSkip}
            onSwipeRight={handleKeep}
          />
        </motion.div>
      </AnimatePresence>

      <div className="flex gap-3">
        <button
          onClick={handleSkip}
          className="flex-1 flex items-center justify-center gap-2 text-[17px] font-bold relative overflow-hidden"
          style={{
            border: 'none',
            borderRadius: 'var(--radius-pill)',
            padding: '16px 24px',
            background: 'var(--bg-surface-raised)',
            boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.05)',
            color: 'var(--text-primary)',
            cursor: 'pointer'
          }}
        >
          Skip
        </button>
        <button
          onClick={handleKeep}
          className="flex-[2] flex items-center justify-center gap-2 text-[17px] font-bold relative overflow-hidden"
          style={{
            border: 'none',
            borderRadius: 'var(--radius-pill)',
            padding: '16px 24px',
            background: 'linear-gradient(135deg, var(--accent-pink-start), var(--accent-pink-end))',
            boxShadow: 'inset 0 2px 0 rgba(255,255,255,0.3), 0 8px 20px rgba(255,0,138,0.3)',
            color: '#FFF',
            cursor: 'pointer'
          }}
        >
          <span 
            className="absolute inset-0 pointer-events-none"
            style={{
              top: 0,
              left: 0,
              right: 0,
              height: '50%',
              background: 'linear-gradient(to bottom, rgba(255,255,255,0.15), transparent)',
              borderRadius: 'var(--radius-pill) var(--radius-pill) 0 0'
            }}
          />
          <RotateCcw className="w-5 h-5" strokeWidth={2.5} />
          Flip Card
        </button>
      </div>
    </div>
  );
}
