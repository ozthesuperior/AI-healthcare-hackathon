import { useState, useEffect } from 'react';

interface Stats {
  totalCasesReviewed: number;
  savedCases: number;
  quizzesCompleted: number;
  blitzRounds: number;
  bestStreak: number;
  averageAccuracy: number;
}

export function Profile() {
  const [stats] = useState<Stats>({
    totalCasesReviewed: 1402,
    savedCases: 0,
    quizzesCompleted: 0,
    blitzRounds: 0,
    bestStreak: 42,
    averageAccuracy: 68,
  });

  const [userName] = useState('Dr. Sarah Jenkins');
  const [userInitials] = useState('SJ');

  return (
    <div 
      className="flex-1 flex flex-col relative z-10 overflow-y-auto"
      style={{ padding: '54px 20px 100px 20px' }}
    >
      <h1 
        className="text-[28px] font-bold mb-6"
        style={{
          marginTop: '20px',
          fontFamily: 'var(--font-rounded)',
          letterSpacing: '-0.5px',
          color: 'var(--text-primary)'
        }}
      >
        Profile
      </h1>

      {/* Profile header */}
      <div className="flex flex-col items-center mb-8">
        <div 
          className="flex items-center justify-center mb-4 relative"
          style={{
            width: '96px',
            height: '96px',
            borderRadius: '50%',
            background: '#333',
            fontSize: '32px',
            fontFamily: 'var(--font-rounded)',
            fontWeight: '700',
            color: 'var(--text-primary)'
          }}
        >
          {userInitials}
          <div 
            className="absolute"
            style={{
              inset: '-3px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, var(--accent-green-start), var(--accent-blue-end), var(--accent-pink-start))',
              zIndex: -1,
              WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
              WebkitMaskComposite: 'xor',
              maskComposite: 'exclude',
              padding: '3px'
            }}
          />
        </div>

        <h2 
          className="text-[22px] font-semibold mb-2"
          style={{
            fontFamily: 'var(--font-rounded)',
            color: 'var(--text-primary)'
          }}
        >
          {userName}
        </h2>
        
        <div 
          className="text-[13px] font-semibold"
          style={{
            background: '#1A1A1C',
            border: '1px solid rgba(0, 229, 255, 0.3)',
            borderRadius: 'var(--radius-pill)',
            padding: '6px 12px',
            color: 'var(--accent-blue-start)'
          }}
        >
          Level 12 — Intern
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3 mb-8">
        <div 
          className="flex flex-col items-center gap-1"
          style={{
            background: 'var(--bg-surface)',
            borderRadius: 'var(--radius-card)',
            padding: '16px',
            border: '1px solid rgba(255,255,255,0.03)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
          }}
        >
          <div 
            className="text-[24px] font-bold"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--text-primary)'
            }}
          >
            {stats.totalCasesReviewed}
          </div>
          <div 
            className="text-[11px] font-semibold uppercase text-center"
            style={{
              color: 'var(--text-secondary)',
              letterSpacing: '0.5px'
            }}
          >
            Total Cases
          </div>
        </div>

        <div 
          className="flex flex-col items-center gap-1"
          style={{
            background: 'var(--bg-surface)',
            borderRadius: 'var(--radius-card)',
            padding: '16px',
            border: '1px solid rgba(255,255,255,0.03)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
          }}
        >
          <div 
            className="text-[24px] font-bold"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--accent-green-start)'
            }}
          >
            {stats.averageAccuracy}%
          </div>
          <div 
            className="text-[11px] font-semibold uppercase text-center"
            style={{
              color: 'var(--text-secondary)',
              letterSpacing: '0.5px'
            }}
          >
            Win Rate
          </div>
        </div>

        <div 
          className="flex flex-col items-center gap-1"
          style={{
            background: 'var(--bg-surface)',
            borderRadius: 'var(--radius-card)',
            padding: '16px',
            border: '1px solid rgba(255,255,255,0.03)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
          }}
        >
          <div 
            className="text-[24px] font-bold"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--accent-yellow-start)'
            }}
          >
            {stats.bestStreak}
          </div>
          <div 
            className="text-[11px] font-semibold uppercase text-center"
            style={{
              color: 'var(--text-secondary)',
              letterSpacing: '0.5px'
            }}
          >
            Best Streak
          </div>
        </div>

        <div 
          className="flex flex-col items-center gap-1"
          style={{
            background: 'var(--bg-surface)',
            borderRadius: 'var(--radius-card)',
            padding: '16px',
            border: '1px solid rgba(255,255,255,0.03)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
          }}
        >
          <div 
            className="text-[24px] font-bold"
            style={{
              fontFamily: 'var(--font-rounded)',
              color: 'var(--accent-blue-start)'
            }}
          >
            850
          </div>
          <div 
            className="text-[11px] font-semibold uppercase text-center"
            style={{
              color: 'var(--text-secondary)',
              letterSpacing: '0.5px'
            }}
          >
            Avg Score
          </div>
        </div>
      </div>

      {/* Recent Sessions */}
      <div 
        className="text-[13px] font-semibold uppercase mb-3"
        style={{
          color: 'var(--text-secondary)',
          letterSpacing: '0.5px'
        }}
      >
        Recent Sessions
      </div>
      
      <div 
        className="flex flex-col"
        style={{
          background: 'var(--bg-surface)',
          borderRadius: 'var(--radius-card)',
          padding: '0',
          border: '1px solid rgba(255,255,255,0.03)',
          boxShadow: '0 8px 32px rgba(0,0,0,0.4)'
        }}
      >
        <div 
          className="flex items-center justify-between"
          style={{
            padding: '16px',
            borderBottom: '1px solid rgba(255,255,255,0.05)'
          }}
        >
          <div>
            <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>
              Blitz Mode - Hard
            </div>
            <div className="text-[13px]" style={{ color: 'var(--text-secondary)', marginTop: '4px' }}>
              Today, 2:40 PM
            </div>
          </div>
          <div 
            className="text-[13px] font-semibold"
            style={{
              background: 'rgba(52, 199, 89, 0.1)',
              borderRadius: 'var(--radius-pill)',
              padding: '6px 12px',
              color: 'var(--accent-green-start)'
            }}
          >
            +240 XP
          </div>
        </div>

        <div 
          className="flex items-center justify-between"
          style={{ padding: '16px' }}
        >
          <div>
            <div className="font-semibold" style={{ color: 'var(--text-primary)' }}>
              Focus - Cardiology
            </div>
            <div className="text-[13px]" style={{ color: 'var(--text-secondary)', marginTop: '4px' }}>
              Yesterday
            </div>
          </div>
          <div 
            className="text-[13px] font-semibold"
            style={{
              background: 'rgba(0, 229, 255, 0.1)',
              borderRadius: 'var(--radius-pill)',
              padding: '6px 12px',
              color: 'var(--accent-blue-start)'
            }}
          >
            +120 XP
          </div>
        </div>
      </div>
    </div>
  );
}
