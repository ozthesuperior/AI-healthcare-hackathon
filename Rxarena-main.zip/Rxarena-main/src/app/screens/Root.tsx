import { Outlet } from 'react-router';
import { BottomTabNav } from '../components/BottomTabNav';
import { DynamicIsland } from '../components/DynamicIsland';

export function Root() {
  return (
    <div className="relative min-h-screen" style={{ background: '#0A0A0A' }}>
      {/* iPhone 17 Pro container */}
      <div 
        className="mx-auto relative overflow-hidden flex flex-col"
        style={{
          width: '402px',
          height: '874px',
          borderRadius: '55px',
          backgroundColor: 'var(--bg-base)',
          boxShadow: '0 0 0 12px #1A1A1A, 0 20px 40px rgba(0,0,0,0.5)'
        }}
      >
        <DynamicIsland />
        <Outlet />
        <BottomTabNav />
      </div>
    </div>
  );
}
